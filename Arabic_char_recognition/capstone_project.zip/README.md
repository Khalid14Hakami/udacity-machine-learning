# Machine Learning Engineer Nanodegree
## Specializations
## Project: Capstone Proposal and Capstone Project

**Note**

you can see the test data in data folder. 

inside data folder there is a jupyter notebook to help visualize the charachters from the test set.

the code for this model is explained in the my_cnn.ipynb and the final model can be found in the src.py 
